A Pen created at CodePen.io. You can find this one at https://codepen.io/samia92/pen/pbJgBj.

 <p>Inspired from Codrops article <a href-"http://tympanus.net/codrops/2013/06/26/expanding-search-bar-deconstructed/" target="_blank">search Bar deconstructed."</a>. With bootstrap navbar and jQuery in stead of vanilla javascript.
        <small>this is a test version, so styles aren't optimized (read:pretty).</small>